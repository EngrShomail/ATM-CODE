print("Please Enter Your Debit Card")
Pin = input("Please Enter Your Pin")
if Pin == "1234":
    print("Welcome","\n")
    print("1. Withdrawal","\n")
    print("2. Balance Enquiry","\n")
    print("3. Fast Cash","\n")
    print("4. Change Pin","\n")
    print("5. Other Services","\n")
    Num = input("Please Enter Your Choice")
    if Num == "1":
        print("1. Rs.1000","\n")
        print("2. Rs.5000","\n")
        print("3. Rs.10000","\n")
        print("4. Rs.20000","\n")
    elif Num == "2":
        print("Your Balance is Rs.10000","\n")
    elif Num == "3":
        print("1. Rs.5000","\n")
        print("2. Rs.10000","\n")
        print("3. Rs.20000","\n")
    elif Num == "4":
        New_Pin = input("Please Enter Your New Pin")
        print("Your Pin is Changed Successfully","\n")
    elif Num == "5":
        print("1. Mini State")
        print("2. Fund Transfer")
        print("3. E-Bill Pay")
        Num1 = input("Please Enter Your Choice") 
        if Num1 == "1":
            print("1. Rs.1000","\n")
        elif Num1 == "2":
            print("Which Account you want to Transfer")
            print("1. Savings Account","\n")
            print("2. Current Account","\n")
        elif Num1 == "3":
            print("Which Bill You Want to Pay","\n")
            print("1. Electricity Bill","\n")
            print("2. Water Bill","\n")
            print("3. Gas Bill","\n")
        else:
            print("Invalid Choice")
    else:
        print("Invalid Choice")
else:
    print("Invalid Pin")